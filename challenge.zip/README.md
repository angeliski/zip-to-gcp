# zip-to-gcp
A simple repo to be ziped and uploaded
 
 # Update to Trigger
